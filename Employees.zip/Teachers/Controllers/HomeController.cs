using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using Teachers.Models;

namespace Teachers.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IUserDetailsService _userDetailsService;

        public HomeController(ILogger<HomeController> logger, IUserDetailsService userDetailsService)
        {
            _logger = logger;
            _userDetailsService = userDetailsService;
        }

        public IActionResult Index()
        {
            return View("SignUp");
        }

        public IActionResult SignUp()
        {
            return View();
        }

        [HttpPost]
        public IActionResult AddUser(EmployessDetails model)
        {
            if (ModelState.IsValid)
            {
                var user = _userDetailsService.AddUserDetails(model);
                return View("Index",user);
            }
            return View("SignUp");
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
