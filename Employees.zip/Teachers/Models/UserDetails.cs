﻿using System.ComponentModel.DataAnnotations;

namespace Teachers.Models
{
    public class UserDetails
    {
        public int Id { get; set; }


        [Required]
        public string Dep_code { get; set; }
        [Required]
        public string Dep_name { get; set; }
        
    }
}
