﻿
using Teachers.Models.TeacherDbContexts;

namespace Teachers.Models
{
    public class UserDetailsService : IUserDetailsService
    {
        public UserDetails _userDetails;
        public TeachersDbContext _teacherDbContexts;

        public UserDetailsService(TeachersDbContext teacherDbContexts, UserDetails userDetails)
        {
            _teacherDbContexts = teacherDbContexts;
            _userDetails = userDetails;
        }


        public EmployessDetails AddUserDetails(EmployessDetails userDetails)
        {
            _teacherDbContexts.Add(userDetails);
            _teacherDbContexts.SaveChanges();
            return userDetails;
        }

    }
}
