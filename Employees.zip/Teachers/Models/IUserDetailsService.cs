﻿namespace Teachers.Models
{
    public interface IUserDetailsService
    {
    
        public EmployessDetails AddUserDetails(EmployessDetails userDetails);
    }
}
