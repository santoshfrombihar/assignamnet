﻿using System.ComponentModel.DataAnnotations;

namespace Teachers.Models
{
    public class EmployessDetails
    {
        public int Id { get; set; }

        [Required]
        public int emp_code { get; set; }

        [Required]
        public string emp_name { get; set; }

        [Required]
        public string emp_panNumber { get; set; }

        [Required]
        public string emp_mobileNumber { get; set; }

        [Required]
        public string emp_email { get; set; }

        [Required]
        public string emp_address { get; set; }

        [Required]
        public int emp_pinCode { get; set; }

 
    }
}
