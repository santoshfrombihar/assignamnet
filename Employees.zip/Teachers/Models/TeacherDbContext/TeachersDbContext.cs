﻿using Microsoft.EntityFrameworkCore;

namespace Teachers.Models.TeacherDbContexts
{
    public class TeachersDbContext : DbContext
    {
        public TeachersDbContext(DbContextOptions<TeachersDbContext> options)
          : base(options)
        {

        }

        DbSet<UserDetails> Users { get; set; }

        DbSet<EmployessDetails> Employees { get; set; }
    }
}
